# netfilix.

- HTML,CSS kullanılarak tasarlandı.

-Video tagı kullanıldı.

<img src="Netflix.gif" />
